class RecipesController < ApplicationController

  def index
    @query = "chocolate"
    @recipes = Recipe.for @query
  end

end
