#605.484 Summer 2016
#Team5-summer16
#Members: Sajjad Syed, Chin-Ting Ko
#Assignment 5
# #Filename: recipe.rb
#Implement a restful API client for http://www.recipepuppy.com/about/api/
#similar to the one we presented in class. It should have a class method
#for, which will take a keyword to search for and use a request parameter
#(q) to send the request up to the API. Also, specify a default parameter
#of onlyImages equal to 1 in order to only return results that contain
#associated thumbnails.


class Recipe

  include HTTParty
  base_uri 'http://www.recipepuppy.com'

  default_params output: "json"
  format :json

  def self.for(q)
    get("/api/?onlyImages=1&q=",query: {q:q})["results"]
  end

end





