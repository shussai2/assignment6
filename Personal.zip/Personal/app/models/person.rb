class Person < ActiveRecord::Base
  has_one :personal_info
end
